package com.example.springbootjpa;


import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootJpaApplicationTests {

    @Test
    void contextLoads() {
    }

}
